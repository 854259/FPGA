module TopModule(input wire clk, input wire [1:0] din, output wire [1:0] q);
assign q = 2'd0;
endmodule
