module TopModule(input wire clk, input wire [2:0] din, output wire [2:0] q);
reg [2:0] history;
always @(posedge clk) begin
history <= din;
end
assign q = (din ^ history);
endmodule
