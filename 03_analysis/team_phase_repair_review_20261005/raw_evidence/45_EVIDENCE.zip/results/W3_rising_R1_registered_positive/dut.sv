module TopModule(input wire clock, input wire [2:0] Word, output reg [2:0] Pulse);
reg [2:0] history;
always @(posedge clock) begin
Pulse <= (Word & ~history);
history <= Word;
end
endmodule
