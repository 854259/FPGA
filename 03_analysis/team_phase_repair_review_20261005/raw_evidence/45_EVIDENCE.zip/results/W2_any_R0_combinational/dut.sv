module TopModule(input wire clk, input wire [1:0] din, output wire [1:0] q);
reg [1:0] history;
always @(posedge clk) begin
history <= din;
end
assign q = (din ^ history);
endmodule
