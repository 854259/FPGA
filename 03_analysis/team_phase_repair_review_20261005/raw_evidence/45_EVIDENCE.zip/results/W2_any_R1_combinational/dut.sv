module TopModule(input wire clock, input wire [1:0] Word, output wire [1:0] Pulse);
reg [1:0] history;
always @(posedge clock) begin
history <= Word;
end
assign Pulse = (Word ^ history);
endmodule
