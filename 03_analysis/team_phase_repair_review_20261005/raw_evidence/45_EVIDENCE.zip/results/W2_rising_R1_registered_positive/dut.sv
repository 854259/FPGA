module TopModule(input wire clock, input wire [1:0] Word, output reg [1:0] Pulse);
reg [1:0] history;
always @(posedge clock) begin
Pulse <= (Word & ~history);
history <= Word;
end
endmodule
