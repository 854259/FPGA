module TopModule(input wire clk, input wire [4:0] din, output reg [4:0] q);
reg [4:0] history;
always @(posedge clk) begin
q <= (din & ~history);
history <= din;
end
endmodule
