module TopModule(input wire clock, input wire [2:0] Word, output wire [2:0] Pulse);
reg [2:0] history;
always @(posedge clock) begin
history <= Word;
end
assign Pulse = (Word ^ history);
endmodule
