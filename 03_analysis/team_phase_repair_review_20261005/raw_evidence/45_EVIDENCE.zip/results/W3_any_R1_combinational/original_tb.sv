`timescale 1ns/1ps
module R2Probe;
reg clock; reg [2:0] Word; wire [2:0] Pulse;
TopModule _edgecheck_dut(.clock(clock),.Word(Word),.Pulse(Pulse));
integer _edgecheck_checks=0,_edgecheck_mismatches=0;
initial begin
clock=0; Word=0; #1;
Word=3'd0; #1;
clock=1; #1;
clock=0; #1;
Word=3'd0; #1;
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=1 phase=positive expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=1 phase=cycle expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=stable expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=positive expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=cycle expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd7; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=stable expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=positive expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=cycle expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd7; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=stable expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=positive expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=cycle expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=stable expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=positive expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=cycle expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd5; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=stable expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd5) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=positive expected=5 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd5) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=cycle expected=5 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd5) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=stable expected=5 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=positive expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=cycle expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=stable expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=positive expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=cycle expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=stable expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=positive expected=1 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=cycle expected=1 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=stable expected=1 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=positive expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=cycle expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd4; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=stable expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=positive expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=cycle expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd6; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=stable expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=positive expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=cycle expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd5; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=stable expected=2 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=positive expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=cycle expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd3; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=stable expected=3 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=positive expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=cycle expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd7; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd6) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=stable expected=6 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=positive expected=4 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=cycle expected=4 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=stable expected=4 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=positive expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=cycle expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
Word=3'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd7) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=stable expected=7 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=1; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=positive expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clock=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
if(Pulse !== 3'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=cycle expected=0 observed=%h",Pulse);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
$display("R2_PROBE_RESULT task=Constructed_W3_any_R1 checks=%0d mismatches=%0d",_edgecheck_checks,_edgecheck_mismatches);
if(_edgecheck_checks!=50) $fatal(1,"CHECK_COUNT_INVALID"); $finish; end
initial begin #10000; $fatal(1,"WATCHDOG_EXPIRED"); end
endmodule
