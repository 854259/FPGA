module TopModule(input wire clock, input wire [1:0] Word, output wire [1:0] Pulse);
assign Pulse = 2'd0;
endmodule
