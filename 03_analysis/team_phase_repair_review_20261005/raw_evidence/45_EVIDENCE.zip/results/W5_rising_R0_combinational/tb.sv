`timescale 1ns/1ps
module R2Probe;
reg clk; reg [4:0] din; wire [4:0] q;
TopModule _edgecheck_dut(.clk(clk),.din(din),.q(q));
integer _edgecheck_checks=0,_edgecheck_mismatches=0;
initial begin
clk=0; din=0; #1;
din=5'd0; #1;
clk=1; #1;
clk=0; #1;
din=5'd0; #1;
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=1 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=1 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd31; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=cycle expected=1f observed=%h",q);
if(q !== 5'd31) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=cycle expected=1f observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd31; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=stable expected=1f observed=%h",q);
if(q !== 5'd31) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=stable expected=1f observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd21; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=cycle expected=15 observed=%h",q);
if(q !== 5'd21) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=cycle expected=15 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd10; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=stable expected=15 observed=%h",q);
if(q !== 5'd21) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=stable expected=15 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=cycle expected=a observed=%h",q);
if(q !== 5'd10) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=cycle expected=a observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=stable expected=a observed=%h",q);
if(q !== 5'd10) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=stable expected=a observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=cycle expected=1 observed=%h",q);
if(q !== 5'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=cycle expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=stable expected=1 observed=%h",q);
if(q !== 5'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=stable expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=cycle expected=2 observed=%h",q);
if(q !== 5'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=cycle expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd4; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=stable expected=2 observed=%h",q);
if(q !== 5'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=stable expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=cycle expected=4 observed=%h",q);
if(q !== 5'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=cycle expected=4 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd8; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=stable expected=4 observed=%h",q);
if(q !== 5'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=stable expected=4 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=cycle expected=8 observed=%h",q);
if(q !== 5'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=cycle expected=8 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd16; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=stable expected=8 observed=%h",q);
if(q !== 5'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=stable expected=8 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=cycle expected=10 observed=%h",q);
if(q !== 5'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=cycle expected=10 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd30; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=stable expected=10 observed=%h",q);
if(q !== 5'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=stable expected=10 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=cycle expected=e observed=%h",q);
if(q !== 5'd14) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=cycle expected=e observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd29; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=stable expected=e observed=%h",q);
if(q !== 5'd14) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=stable expected=e observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=cycle expected=1 observed=%h",q);
if(q !== 5'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=cycle expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd27; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=16 phase=stable expected=1 observed=%h",q);
if(q !== 5'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=stable expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=16 phase=cycle expected=2 observed=%h",q);
if(q !== 5'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=cycle expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd23; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=17 phase=stable expected=2 observed=%h",q);
if(q !== 5'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=stable expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=17 phase=cycle expected=4 observed=%h",q);
if(q !== 5'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=cycle expected=4 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd15; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=18 phase=stable expected=4 observed=%h",q);
if(q !== 5'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=18 phase=stable expected=4 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=18 phase=cycle expected=8 observed=%h",q);
if(q !== 5'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=18 phase=cycle expected=8 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd31; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=19 phase=stable expected=8 observed=%h",q);
if(q !== 5'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=19 phase=stable expected=8 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=19 phase=cycle expected=10 observed=%h",q);
if(q !== 5'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=19 phase=cycle expected=10 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=20 phase=stable expected=10 observed=%h",q);
if(q !== 5'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=20 phase=stable expected=10 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=20 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=20 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=5'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=21 phase=stable expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=21 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=21 phase=cycle expected=0 observed=%h",q);
if(q !== 5'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=21 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
$display("R2_PROBE_RESULT task=Constructed_W5_rising_R0 checks=%0d mismatches=%0d",_edgecheck_checks,_edgecheck_mismatches);
if(_edgecheck_checks!=41) $fatal(1,"CHECK_COUNT_INVALID"); $finish; end
initial begin #10000; $fatal(1,"WATCHDOG_EXPIRED"); end
endmodule
