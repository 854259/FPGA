module TopModule(input wire clk, input wire [2:0] din, output wire [2:0] q);
assign q = 3'd0;
endmodule
