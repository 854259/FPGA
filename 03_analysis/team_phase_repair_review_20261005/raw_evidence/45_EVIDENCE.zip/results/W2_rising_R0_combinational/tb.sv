`timescale 1ns/1ps
module R2Probe;
reg clk; reg [1:0] din; wire [1:0] q;
TopModule _edgecheck_dut(.clk(clk),.din(din),.q(q));
integer _edgecheck_checks=0,_edgecheck_mismatches=0;
initial begin
clk=0; din=0; #1;
din=2'd0; #1;
clk=1; #1;
clk=0; #1;
din=2'd0; #1;
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=1 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=1 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd3; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=cycle expected=3 observed=%h",q);
if(q !== 2'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=cycle expected=3 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd3; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=stable expected=3 observed=%h",q);
if(q !== 2'd3) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=stable expected=3 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=cycle expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=cycle expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=stable expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=stable expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=cycle expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=cycle expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=stable expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=stable expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=cycle expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=cycle expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=stable expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=stable expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=cycle expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=cycle expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=stable expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=stable expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=cycle expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=cycle expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd3; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=stable expected=1 observed=%h",q);
if(q !== 2'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=stable expected=1 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=cycle expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=cycle expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=stable expected=2 observed=%h",q);
if(q !== 2'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=stable expected=2 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
din=2'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=stable expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=stable expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=cycle expected=0 observed=%h",q);
if(q !== 2'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=cycle expected=0 observed=%h",q);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
$display("R2_PROBE_RESULT task=Constructed_W2_rising_R0 checks=%0d mismatches=%0d",_edgecheck_checks,_edgecheck_mismatches);
if(_edgecheck_checks!=29) $fatal(1,"CHECK_COUNT_INVALID"); $finish; end
initial begin #10000; $fatal(1,"WATCHDOG_EXPIRED"); end
endmodule
