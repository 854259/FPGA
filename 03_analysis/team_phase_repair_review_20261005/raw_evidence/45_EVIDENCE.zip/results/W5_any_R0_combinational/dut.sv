module TopModule(input wire clk, input wire [4:0] din, output wire [4:0] q);
reg [4:0] history;
always @(posedge clk) begin
history <= din;
end
assign q = (din ^ history);
endmodule
