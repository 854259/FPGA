module TopModule(input wire clock, input wire [4:0] Word, output reg [4:0] Pulse);
reg [4:0] history;
always @(negedge clock) begin
Pulse <= (Word & ~history);
history <= Word;
end
endmodule
