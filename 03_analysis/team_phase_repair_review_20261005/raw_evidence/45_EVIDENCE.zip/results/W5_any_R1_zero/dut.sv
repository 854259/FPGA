module TopModule(input wire clock, input wire [4:0] Word, output wire [4:0] Pulse);
assign Pulse = 5'd0;
endmodule
