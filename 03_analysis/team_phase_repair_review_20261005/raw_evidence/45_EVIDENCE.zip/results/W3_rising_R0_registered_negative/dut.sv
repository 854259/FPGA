module TopModule(input wire clk, input wire [2:0] din, output reg [2:0] q);
reg [2:0] history;
always @(negedge clk) begin
q <= (din & ~history);
history <= din;
end
endmodule
