module TopModule(input wire clk, input wire [1:0] din, output reg [1:0] q);
reg [1:0] history;
always @(negedge clk) begin
q <= (din ^ history);
history <= din;
end
endmodule
