module TopModule(input wire clock, input wire [2:0] Word, output wire [2:0] Pulse);
assign Pulse = 3'd0;
endmodule
