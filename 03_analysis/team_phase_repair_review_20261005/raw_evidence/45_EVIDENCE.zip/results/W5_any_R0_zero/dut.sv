module TopModule(input wire clk, input wire [4:0] din, output wire [4:0] q);
assign q = 5'd0;
endmodule
