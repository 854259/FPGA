module TopModule(input wire clock, input wire [4:0] Word, output wire [4:0] Pulse);
reg [4:0] history;
always @(posedge clock) begin
history <= Word;
end
assign Pulse = (Word ^ history);
endmodule
