xsim {r2_probe} -autoloadwcfg -runall
