module TopModule (
    input clk,
    input [7:0] in,
    output [7:0] anyedge
);

    reg [7:0] in_prev;
    reg [7:0] in_prev2;

    always @(posedge clk) begin
        in_prev  <= in;
        in_prev2 <= in_prev;
    end

    assign anyedge = in_prev ^ in_prev2;

endmodule
