`timescale 1ns/1ps
module R2Probe;
reg clk; reg [7:0] in; wire [7:0] pedge;
TopModule _edgecheck_dut(.clk(clk),.in(in),.pedge(pedge));
integer _edgecheck_checks=0,_edgecheck_mismatches=0;
initial begin
clk=0; in=0; #1;
in=8'd0; #1;
clk=1; #1;
clk=0; #1;
in=8'd0; #1;
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=1 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=1 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=2 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=2 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd255; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=3 phase=cycle expected=ff observed=%h",pedge);
if(pedge !== 8'd255) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=3 phase=cycle expected=ff observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd255; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=stable expected=ff observed=%h",pedge);
if(pedge !== 8'd255) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=stable expected=ff observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=4 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=4 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=5 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=5 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd85; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=6 phase=cycle expected=55 observed=%h",pedge);
if(pedge !== 8'd85) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=6 phase=cycle expected=55 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd170; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=stable expected=55 observed=%h",pedge);
if(pedge !== 8'd85) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=stable expected=55 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=7 phase=cycle expected=aa observed=%h",pedge);
if(pedge !== 8'd170) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=7 phase=cycle expected=aa observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=stable expected=aa observed=%h",pedge);
if(pedge !== 8'd170) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=stable expected=aa observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=8 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=8 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd1; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=9 phase=cycle expected=1 observed=%h",pedge);
if(pedge !== 8'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=9 phase=cycle expected=1 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd2; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=stable expected=1 observed=%h",pedge);
if(pedge !== 8'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=stable expected=1 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=10 phase=cycle expected=2 observed=%h",pedge);
if(pedge !== 8'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=10 phase=cycle expected=2 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd4; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=stable expected=2 observed=%h",pedge);
if(pedge !== 8'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=stable expected=2 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=11 phase=cycle expected=4 observed=%h",pedge);
if(pedge !== 8'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=11 phase=cycle expected=4 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd8; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=stable expected=4 observed=%h",pedge);
if(pedge !== 8'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=stable expected=4 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=12 phase=cycle expected=8 observed=%h",pedge);
if(pedge !== 8'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=12 phase=cycle expected=8 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd16; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=stable expected=8 observed=%h",pedge);
if(pedge !== 8'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=stable expected=8 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=13 phase=cycle expected=10 observed=%h",pedge);
if(pedge !== 8'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=13 phase=cycle expected=10 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd32; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=stable expected=10 observed=%h",pedge);
if(pedge !== 8'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=stable expected=10 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=14 phase=cycle expected=20 observed=%h",pedge);
if(pedge !== 8'd32) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=14 phase=cycle expected=20 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd64; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=stable expected=20 observed=%h",pedge);
if(pedge !== 8'd32) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=stable expected=20 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=15 phase=cycle expected=40 observed=%h",pedge);
if(pedge !== 8'd64) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=15 phase=cycle expected=40 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd128; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=16 phase=stable expected=40 observed=%h",pedge);
if(pedge !== 8'd64) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=stable expected=40 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=16 phase=cycle expected=80 observed=%h",pedge);
if(pedge !== 8'd128) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=16 phase=cycle expected=80 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd254; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=17 phase=stable expected=80 observed=%h",pedge);
if(pedge !== 8'd128) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=stable expected=80 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=17 phase=cycle expected=7e observed=%h",pedge);
if(pedge !== 8'd126) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=17 phase=cycle expected=7e observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd253; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=18 phase=stable expected=7e observed=%h",pedge);
if(pedge !== 8'd126) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=18 phase=stable expected=7e observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=18 phase=cycle expected=1 observed=%h",pedge);
if(pedge !== 8'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=18 phase=cycle expected=1 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd251; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=19 phase=stable expected=1 observed=%h",pedge);
if(pedge !== 8'd1) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=19 phase=stable expected=1 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=19 phase=cycle expected=2 observed=%h",pedge);
if(pedge !== 8'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=19 phase=cycle expected=2 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd247; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=20 phase=stable expected=2 observed=%h",pedge);
if(pedge !== 8'd2) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=20 phase=stable expected=2 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=20 phase=cycle expected=4 observed=%h",pedge);
if(pedge !== 8'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=20 phase=cycle expected=4 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd239; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=21 phase=stable expected=4 observed=%h",pedge);
if(pedge !== 8'd4) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=21 phase=stable expected=4 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=21 phase=cycle expected=8 observed=%h",pedge);
if(pedge !== 8'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=21 phase=cycle expected=8 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd223; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=22 phase=stable expected=8 observed=%h",pedge);
if(pedge !== 8'd8) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=22 phase=stable expected=8 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=22 phase=cycle expected=10 observed=%h",pedge);
if(pedge !== 8'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=22 phase=cycle expected=10 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd191; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=23 phase=stable expected=10 observed=%h",pedge);
if(pedge !== 8'd16) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=23 phase=stable expected=10 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=23 phase=cycle expected=20 observed=%h",pedge);
if(pedge !== 8'd32) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=23 phase=cycle expected=20 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd127; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=24 phase=stable expected=20 observed=%h",pedge);
if(pedge !== 8'd32) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=24 phase=stable expected=20 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=24 phase=cycle expected=40 observed=%h",pedge);
if(pedge !== 8'd64) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=24 phase=cycle expected=40 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd255; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=25 phase=stable expected=40 observed=%h",pedge);
if(pedge !== 8'd64) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=25 phase=stable expected=40 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=25 phase=cycle expected=80 observed=%h",pedge);
if(pedge !== 8'd128) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=25 phase=cycle expected=80 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=26 phase=stable expected=80 observed=%h",pedge);
if(pedge !== 8'd128) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=26 phase=stable expected=80 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=26 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=26 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
in=8'd0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=27 phase=stable expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=27 phase=stable expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
clk=1; #1;
clk=0; #1;
_edgecheck_checks=_edgecheck_checks+1;
$display("EDGE_TRACE step=27 phase=cycle expected=0 observed=%h",pedge);
if(pedge !== 8'd0) begin
if(_edgecheck_mismatches==0) $display("EDGE_FIRST step=27 phase=cycle expected=0 observed=%h",pedge);
_edgecheck_mismatches=_edgecheck_mismatches+1; end
$display("R2_PROBE_RESULT task=Prob054_edgedetect checks=%0d mismatches=%0d",_edgecheck_checks,_edgecheck_mismatches);
if(_edgecheck_checks!=53) $fatal(1,"CHECK_COUNT_INVALID"); $finish; end
initial begin #10000; $fatal(1,"WATCHDOG_EXPIRED"); end
endmodule
